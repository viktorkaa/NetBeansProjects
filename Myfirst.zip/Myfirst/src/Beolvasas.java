/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user3
 */
public class Beolvasas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     //Random szám generálás:
     //(int)(Math.random() * intervallum_mérete) + alsó;
    
     int randomSzam = (int)(Math.random() * 21) + 10; //10-20 közötti szám.
     System.out.println(randomSzam);
    }
    
}
