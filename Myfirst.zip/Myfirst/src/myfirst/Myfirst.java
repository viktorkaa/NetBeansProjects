/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirst;

/**
 *
 * @author user3
 */
public class Myfirst {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");
    
    //deklaráció
    int szam = 15;
    System.out.print("A megadott érték: ");
    System.out.println(szam);
    System.out.println("A megadott érték: " +szam);
    
    double magassag = 1.80;
    System.out.println("Magasságom:"+magassag +"cm");
    System.out.println("Magasságom:"+magassag*100 +"cm");
    
    }
    
    
    
}
